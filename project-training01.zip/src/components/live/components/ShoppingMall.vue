<template>
  <div class="ShoppingMall">{{msg}}</div>
</template>

<script>
export default {
  name: 'ShoppingMall',
  data () {
    return {
      msg: 'ShoppingMall'
    }
  }
}
</script>

<style>
</style>
