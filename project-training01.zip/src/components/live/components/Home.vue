<template>
  <div class="home">{{msg}}</div>
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
      msg: 'home'
    }
  }
}
</script>

<style>
</style>
