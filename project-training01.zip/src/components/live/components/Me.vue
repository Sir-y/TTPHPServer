<template>
  <div class="Me">{{msg}}</div>
</template>

<script>
export default {
  name: 'Me',
  data () {
    return {
      msg: 'Me'
    }
  }
}
</script>

<style>
</style>
