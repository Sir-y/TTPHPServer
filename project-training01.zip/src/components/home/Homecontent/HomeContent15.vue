<template>
  <div class>
    <Record></Record>
  </div>
</template>
<script>
import Record from '@/components/me/components/Record'
export default {
  name: 'HomeContent15',
  components: {
    Record
  }
}
</script>
<style scoped lang="less">
</style>
