<template>
  <div class="getback">
    <i class="iconfont">&#xe682;</i>
  </div>
</template>

<script>
export default {
  name: 'GetBack'
}
</script>

<style scoped lang="less">
.getback {
  width: 100%;
  height: 100%;
  i {
    width: 100%;
    height: 100%;
    text-align: center;
    display: inline-block;
  }
}
</style>
