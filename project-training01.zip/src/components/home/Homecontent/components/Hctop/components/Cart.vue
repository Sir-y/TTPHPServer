<template>
  <div class="cart">
    <i class="iconfont icon-cart">&#xe6a9;</i>
  </div>
</template>

<script>
export default {
  name: 'Cart'
}
</script>

<style scoped lang="less">
.cart {
  width: 100%;
  height: 100%;
  text-align: center;
  .icon-cart {
    color: #727272;
    font-size: 20 * 2px;
  }
}
</style>
